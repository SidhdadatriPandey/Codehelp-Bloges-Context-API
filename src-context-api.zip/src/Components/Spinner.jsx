import React from 'react'

const Spinner = () => {
  return (
    <div className='spinner-parent'>
      <div className='spinner'>
      
      </div>
    </div>
  )
}

export default Spinner
