import React from 'react'

const Header: React.FC = () => {
  return (
    <div>
      <h1 className='heading'>Codehelp bloges</h1>
    </div>
  )
}

export default Header
